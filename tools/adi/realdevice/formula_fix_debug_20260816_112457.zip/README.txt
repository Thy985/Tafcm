FormulaFix Debug Report
========================

This archive contains diagnostic data for debugging.

Files:
  metadata.json           - App version, device, OS, session info
  trace.json              - Interaction + Command + Transaction + Render traces
  snapshot.json           - Error snapshot (if any)
  invariant_report.json   - Invariant checker results
  commands.jsonl          - Replay sequence (AS-RG.1, if commands recorded)
  replay.json             - App-side replay result (if replay was run)

For analysis:
  python tools/ffx-analyze/analyze.py this_file.zip
